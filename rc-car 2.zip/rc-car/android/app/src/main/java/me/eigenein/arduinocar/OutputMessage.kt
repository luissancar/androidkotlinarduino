package me.eigenein.arduinocar

import java.io.OutputStream

interface OutputMessage

data class BotonUno(val unit: Unit) : OutputMessage
data class BotonDos(val unit: Unit) : OutputMessage
data class BotonTres(val unit: Unit) : OutputMessage

val botonUno = BotonUno(Unit)
val botonDos = BotonDos(Unit)
val botonTres = BotonTres(Unit)
/*
fun OutputStream.writeMessage(message: OutputMessage) = write(

    when (message) {
        is DeprecatedNoOperationOutputMessage -> byteArrayOf(0x01)
        is DeprecatedBrakeOutputMessage -> byteArrayOf(0x02)
        is DeprecatedMoveOutputMessage -> byteArrayOf(
            0x03,
            speedToByte(message.left),
            if (message.left < 0f) 1 else 0,
            speedToByte(message.right),
            if (message.right < 0f) 1 else 0
        )
        else -> byteArrayOf()
    }
)
*/


fun OutputStream.writeMessage(message: OutputMessage) = write(

        when (message) {
            is BotonUno -> 49
            is BotonDos -> 50
            is BotonTres -> 51
            else -> 90
        }
)


private fun speedToByte(speed: Float) = (Math.abs(speed) * 255f).toByte()
